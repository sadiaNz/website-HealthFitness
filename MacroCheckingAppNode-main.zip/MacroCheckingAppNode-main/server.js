const express = require('express');
const app = express();
const userRouter = require('./routes/objects'); // Ensure this path is correct

// Middleware to serve static files
app.use(express.static('public')); // For CSS and other static files
app.use('/images', express.static('images')); // For serving images

app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.set('view engine', 'ejs');

// Route to render the home page
app.get('/', (req, res) => {
    res.render('index');
});

// Route to render the macro fitness page
app.get('/macro-fitness', (req, res) => {
    res.render('macro-fitness');
});

// Route to render the login page
app.get('/login', (req, res) => {
    res.render('login');
});

// Use the router for /objects routes
app.use('/objects', userRouter);

// Route to render the calculator page
app.get('/calculator', (req, res) => {
    res.render('calculator');
});

// Start the server
app.listen(3000, () => {
    console.log('Server is running on http://localhost:3000');
});
