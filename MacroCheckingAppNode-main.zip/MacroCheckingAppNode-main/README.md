# MacroCheckingAppNode
An app that simulates my fitness pal on a smaller level
